<?php

$id = (string)($_GET['id']);
header('Location: messages.php');

?>