<?php

$dbuser = "root";
$dbpass = "";
$dbhost = "localhost";
$dbname = "soulmatch";

$connect = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);