<?php


include('dbconfig.php');


// query untuk mendapat database chat
if(isset($_GET['id'])){
$receiver = (string)($_GET['id']);
$querychat = "select * from chat where from_user ='".$_COOKIE['username']."' and to_user = '{$receiver}' or from_user = '".$receiver."' and to_user = '{$_COOKIE['username']}' ORDER BY time ASC";
$resultchat = mysqli_query($connect,$querychat);
$count = mysqli_num_rows($resultchat);


}

// untuk mendapat data username dan isi chat

?>